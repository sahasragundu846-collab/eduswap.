import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Package, Plus, Loader2, Calendar, CheckCircle2 } from "lucide-react";
import { Session } from "@supabase/supabase-js";
import { toast } from "sonner";

interface Item {
  id: string;
  title: string;
  description: string | null;
  category: string | null;
  condition: string | null;
  is_available: boolean;
  owner_id: string;
  profiles: {
    full_name: string;
  };
}

const Borrow = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [itemForm, setItemForm] = useState({
    title: "",
    description: "",
    category: "",
    condition: "",
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        fetchItems();
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const fetchItems = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("items")
      .select(`
        *,
        profiles (full_name)
      `)
      .order("created_at", { ascending: false });

    if (!error && data) {
      setItems(data);
    }
    setLoading(false);
  };

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session?.user) return;

    setSubmitting(true);

    try {
      const { error } = await supabase
        .from("items")
        .insert({
          owner_id: session.user.id,
          title: itemForm.title,
          description: itemForm.description,
          category: itemForm.category,
          condition: itemForm.condition,
        });

      if (error) throw error;

      toast.success("Item added successfully!");
      setItemForm({ title: "", description: "", category: "", condition: "" });
      fetchItems();
    } catch (error: any) {
      toast.error(error.message || "Error adding item");
    } finally {
      setSubmitting(false);
    }
  };

  const handleBorrow = async (itemId: string, ownerId: string) => {
    if (!session?.user) return;

    try {
      const dueDate = new Date();
      dueDate.setDate(dueDate.getDate() + 14); // 2 weeks from now

      const { error: borrowError } = await supabase
        .from("borrows")
        .insert({
          item_id: itemId,
          borrower_id: session.user.id,
          owner_id: ownerId,
          due_date: dueDate.toISOString(),
        });

      if (borrowError) throw borrowError;

      const { error: updateError } = await supabase
        .from("items")
        .update({ is_available: false })
        .eq("id", itemId);

      if (updateError) throw updateError;

      toast.success("Item borrowed successfully! Due in 2 weeks");
      fetchItems();
    } catch (error: any) {
      toast.error(error.message || "Error borrowing item");
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Borrow Items</h1>
            <p className="text-muted-foreground">Exchange textbooks, calculators, and more</p>
          </div>

          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add Item to Lend</DialogTitle>
                <DialogDescription>List an item you want to share with others</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleAddItem} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="item-title">Title</Label>
                  <Input
                    id="item-title"
                    value={itemForm.title}
                    onChange={(e) => setItemForm({ ...itemForm, title: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="item-category">Category</Label>
                  <Select value={itemForm.category} onValueChange={(value) => setItemForm({ ...itemForm, category: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="textbook">Textbook</SelectItem>
                      <SelectItem value="calculator">Calculator</SelectItem>
                      <SelectItem value="electronics">Electronics</SelectItem>
                      <SelectItem value="supplies">Supplies</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="item-condition">Condition</Label>
                  <Select value={itemForm.condition} onValueChange={(value) => setItemForm({ ...itemForm, condition: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="like-new">Like New</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="fair">Fair</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="item-description">Description</Label>
                  <Textarea
                    id="item-description"
                    value={itemForm.description}
                    onChange={(e) => setItemForm({ ...itemForm, description: e.target.value })}
                    rows={3}
                  />
                </div>
                <Button type="submit" className="w-full" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    "Add Item"
                  )}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {loading ? (
          <div className="flex items-center justify-center min-h-[40vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {items.map((item) => (
              <Card key={item.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <Package className="h-8 w-8 text-primary" />
                    <div className="flex gap-2">
                      {item.category && (
                        <Badge variant="secondary">{item.category}</Badge>
                      )}
                      <Badge variant={item.is_available ? "default" : "outline"}>
                        {item.is_available ? "Available" : "Borrowed"}
                      </Badge>
                    </div>
                  </div>
                  <CardTitle className="line-clamp-2">{item.title}</CardTitle>
                  <CardDescription className="line-clamp-2">
                    {item.description || "No description"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Owner:</span>
                    <span className="font-medium">{item.profiles.full_name}</span>
                  </div>
                  {item.condition && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Condition:</span>
                      <span className="font-medium capitalize">{item.condition}</span>
                    </div>
                  )}
                  {item.is_available && item.owner_id !== session?.user?.id && (
                    <Button
                      className="w-full mt-2"
                      onClick={() => handleBorrow(item.id, item.owner_id)}
                    >
                      <Calendar className="mr-2 h-4 w-4" />
                      Borrow (2 weeks)
                    </Button>
                  )}
                  {!item.is_available && (
                    <Button className="w-full mt-2" variant="outline" disabled>
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Currently Borrowed
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && items.length === 0 && (
          <div className="text-center py-12">
            <Package className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-semibold">No items available</h3>
            <p className="text-muted-foreground">Be the first to add an item!</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Borrow;
