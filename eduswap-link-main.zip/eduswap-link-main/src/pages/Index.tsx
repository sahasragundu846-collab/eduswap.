import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { BookOpen, FileText, Package, Bell, ArrowRight } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary via-secondary to-primary">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center text-white space-y-8">
          <div className="inline-block p-4 bg-white/10 rounded-2xl backdrop-blur-sm">
            <BookOpen className="w-16 h-16" />
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold">Welcome to EduSwap</h1>
          <p className="text-xl md:text-2xl text-white/90">
            Your campus community for sharing knowledge and resources
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <Button size="lg" variant="secondary" onClick={() => navigate("/auth")} className="text-lg">
              Get Started <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-6 pt-16">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 space-y-3">
              <FileText className="w-10 h-10 mx-auto" />
              <h3 className="text-xl font-semibold">Share Resources</h3>
              <p className="text-white/80">Upload and download study materials, notes, and slides</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 space-y-3">
              <Package className="w-10 h-10 mx-auto" />
              <h3 className="text-xl font-semibold">Borrow Items</h3>
              <p className="text-white/80">Exchange textbooks, calculators, and equipment</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 space-y-3">
              <Bell className="w-10 h-10 mx-auto" />
              <h3 className="text-xl font-semibold">Stay Updated</h3>
              <p className="text-white/80">Get real-time campus announcements and events</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
