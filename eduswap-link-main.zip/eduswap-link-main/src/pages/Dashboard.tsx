import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, FileText, Package, TrendingUp, AlertCircle } from "lucide-react";
import { Session } from "@supabase/supabase-js";

const Dashboard = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    resources: 0,
    borrowed: 0,
    overdue: 0,
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        fetchStats(session.user.id);
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const fetchStats = async (userId: string) => {
    const [resourcesResult, borrowedResult, overdueResult] = await Promise.all([
      supabase.from("resources").select("id", { count: "exact" }).eq("user_id", userId),
      supabase.from("borrows").select("id", { count: "exact" }).eq("borrower_id", userId).eq("status", "active"),
      supabase.from("borrows").select("id", { count: "exact" }).eq("borrower_id", userId).eq("is_overdue", true),
    ]);

    setStats({
      resources: resourcesResult.count || 0,
      borrowed: borrowedResult.count || 0,
      overdue: overdueResult.count || 0,
    });
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back!</h1>
          <p className="text-muted-foreground">Here's your academic community overview</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Your Resources</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.resources}</div>
              <p className="text-xs text-muted-foreground">Files shared with community</p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Items Borrowed</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.borrowed}</div>
              <p className="text-xs text-muted-foreground">Currently in your possession</p>
            </CardContent>
          </Card>

          <Card className={`hover:shadow-md transition-shadow ${stats.overdue > 0 ? "border-warning" : ""}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overdue Items</CardTitle>
              <AlertCircle className={`h-4 w-4 ${stats.overdue > 0 ? "text-warning" : "text-muted-foreground"}`} />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stats.overdue > 0 ? "text-warning" : ""}`}>{stats.overdue}</div>
              <p className="text-xs text-muted-foreground">Please return soon</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Share Resources
              </CardTitle>
              <CardDescription>Upload notes, slides, and study materials for your peers</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate("/resources")} className="w-full">
                <TrendingUp className="mr-2 h-4 w-4" />
                Explore Resources
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Borrow Items
              </CardTitle>
              <CardDescription>Exchange textbooks, calculators, and other physical items</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate("/borrow")} className="w-full">
                <BookOpen className="mr-2 h-4 w-4" />
                Browse Items
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
