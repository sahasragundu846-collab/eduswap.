import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Shield, AlertTriangle, Plus, CheckCircle2 } from "lucide-react";
import { Session } from "@supabase/supabase-js";
import { toast } from "sonner";

interface OverdueBorrow {
  id: string;
  due_date: string;
  borrowed_at: string;
  items: { title: string };
  profiles: { full_name: string; email: string };
}

const Admin = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [overdueBorrows, setOverdueBorrows] = useState<OverdueBorrow[]>([]);
  const [loading, setLoading] = useState(true);
  const [announcementForm, setAnnouncementForm] = useState({
    title: "",
    content: "",
    category: "general",
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        checkAdminAndFetch(session.user.id);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const checkAdminAndFetch = async (userId: string) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();

    if (!data) {
      toast.error("Access denied: Admin only");
      navigate("/dashboard");
      return;
    }

    setIsAdmin(true);
    fetchOverdueBorrows();
    setLoading(false);
  };

  const fetchOverdueBorrows = async () => {
    const { data } = await supabase
      .from("borrows")
      .select(`
        *,
        items (title),
        profiles:borrower_id (full_name, email)
      `)
      .eq("is_overdue", true)
      .order("due_date", { ascending: true });

    if (data) setOverdueBorrows(data as any);
  };

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session?.user) return;

    try {
      const { error } = await supabase.from("announcements").insert({
        author_id: session.user.id,
        title: announcementForm.title,
        content: announcementForm.content,
        category: announcementForm.category,
      });

      if (error) throw error;

      toast.success("Announcement posted!");
      setAnnouncementForm({ title: "", content: "", category: "general" });
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const markAsReturned = async (borrowId: string, itemId: string) => {
    try {
      await supabase.from("borrows").update({ returned_at: new Date().toISOString(), status: "returned" }).eq("id", borrowId);
      await supabase.from("items").update({ is_available: true }).eq("id", itemId);
      toast.success("Marked as returned");
      fetchOverdueBorrows();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Shield className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Admin Panel</h1>
            <p className="text-muted-foreground">Manage announcements and track overdue items</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Create Announcement</CardTitle>
            <CardDescription>Post updates, events, or urgent notices</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateAnnouncement} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ann-title">Title</Label>
                  <Input
                    id="ann-title"
                    value={announcementForm.title}
                    onChange={(e) => setAnnouncementForm({ ...announcementForm, title: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ann-category">Category</Label>
                  <Select value={announcementForm.category} onValueChange={(value) => setAnnouncementForm({ ...announcementForm, category: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="event">Event</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ann-content">Content</Label>
                <Textarea
                  id="ann-content"
                  value={announcementForm.content}
                  onChange={(e) => setAnnouncementForm({ ...announcementForm, content: e.target.value })}
                  rows={4}
                  required
                />
              </div>
              <Button type="submit">
                <Plus className="mr-2 h-4 w-4" />
                Post Announcement
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-warning" />
              Overdue Items ({overdueBorrows.length})
            </CardTitle>
            <CardDescription>Items that need to be returned</CardDescription>
          </CardHeader>
          <CardContent>
            {overdueBorrows.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No overdue items</p>
            ) : (
              <div className="space-y-3">
                {overdueBorrows.map((borrow) => (
                  <div key={borrow.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">{borrow.items.title}</p>
                      <p className="text-sm text-muted-foreground">
                        Borrower: {borrow.profiles.full_name} • Due: {new Date(borrow.due_date).toLocaleDateString()}
                      </p>
                    </div>
                    <Button size="sm" variant="outline">
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Mark Returned
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Admin;
